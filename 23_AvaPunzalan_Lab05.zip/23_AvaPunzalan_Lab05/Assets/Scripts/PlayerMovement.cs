﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    public Rigidbody PlayerRigidbody;

    private int coinGain;
    private int coinCounter = 3;
    public Text coinText;

    public GameObject GameWinLayout;
    public GameObject GameLoseLayout;
    public GameObject playerObject;

    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
        coinText.GetComponent<Text>().text = "Coins: " + coinGain;
    }

    void FixedUpdate()
    {

        float moveHorizontal = Input.GetAxis("Horizontal");

        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);

        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);

    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Hazard")
        {
            Destroy(playerObject);
            GameLoseLayout.SetActive(true);
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Coin")
        {
            coinGain++;
            Destroy(other.gameObject);
            coinText.GetComponent<Text>().text = "Coins: " + coinGain;

            if (coinGain == coinCounter)
            {
                Destroy(playerObject);
                GameWinLayout.SetActive(true);
            }
        }
    }
}
