﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinScript : MonoBehaviour
{
    public float rotateSpeed;

    // Start is called before the first frame update
    void Start()
    {
        //transform.Rotate(Vector3.right * rotateSpeed * Time.deltaTime);
    }
    void Update()
    {
        transform.Rotate(rotateSpeed * Time.deltaTime);

    }
}
